import pandas as pd
import matplotlib.pyplot as plt

df = pd.read_csv("cleaned_data.csv")

season = df.groupby('Season')['Monthly_Rate'].mean()

plt.figure()
season.plot(kind='bar', color='orange')
plt.title("Season-wise Analysis")
plt.show()

