import pandas as pd
import matplotlib.pyplot as plt
from pandas.plotting import scatter_matrix

df = pd.read_csv("cleaned_data.csv")

# Convert categorical to numeric
df['Age_Code'] = df['Age_Category'].astype('category').cat.codes
df['Sex_Code'] = df['Sex'].astype('category').cat.codes
df['Race_Code'] = df['Race'].astype('category').cat.codes

# Select columns for correlation
data = df[['Monthly_Rate', 'Age_Code', 'Sex_Code', 'Race_Code']]

# Scatter matrix (correlation graph)
plt.figure()
scatter_matrix(data)

plt.suptitle("Correlation Graph (Scatter Matrix)")
plt.show()