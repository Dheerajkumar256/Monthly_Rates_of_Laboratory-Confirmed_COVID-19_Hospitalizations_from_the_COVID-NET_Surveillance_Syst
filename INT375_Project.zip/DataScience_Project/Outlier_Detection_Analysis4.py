import pandas as pd
import matplotlib.pyplot as plt

df = pd.read_csv("cleaned_data.csv")

plt.figure()

df.boxplot(column='Monthly_Rate', by='Age_Category')

plt.title("Box Plot: Age Category vs Hospitalization Rate")
plt.suptitle("")  # remove extra title

plt.xlabel("Age Category")
plt.ylabel("Monthly Rate")

plt.xticks(rotation=75)

plt.show()
