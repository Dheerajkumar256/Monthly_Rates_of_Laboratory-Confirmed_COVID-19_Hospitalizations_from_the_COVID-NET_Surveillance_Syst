import pandas as pd
import matplotlib.pyplot as plt

df = pd.read_csv("cleaned_data.csv")

# Convert Age_Category to numeric (if needed)
df['Age_Category_Code'] = df['Age_Category'].astype('category').cat.codes

plt.figure()
plt.scatter(df['Age_Category_Code'], df['Monthly_Rate'])

plt.title("Age vs Hospitalization Rate")
plt.xlabel("Age Category")
plt.ylabel("Monthly Rate")

plt.show()