import pandas as pd
import matplotlib.pyplot as plt

# Load data
df = pd.read_csv("cleaned_data.csv")

# Convert categorical to numeric
df['Age_Code'] = df['Age_Category'].astype('category').cat.codes
df['Sex_Code'] = df['Sex'].astype('category').cat.codes
df['Race_Code'] = df['Race'].astype('category').cat.codes

# Correlation matrix
numeric_df = df[['Monthly_Rate', 'Age_Code', 'Sex_Code', 'Race_Code']]
corr = numeric_df.corr()

# Create equal grid layout
fig, axes = plt.subplots(2, 3, figsize=(16,10))

#  1 Scatter Plot
axes[0,0].scatter(df['Age_Code'], df['Monthly_Rate'])
axes[0,0].set_title("Scatter Plot")

# 🔹 2 Heatmap
im = axes[0,1].imshow(corr)
axes[0,1].set_title("Heatmap")
axes[0,1].set_xticks(range(len(corr.columns)))
axes[0,1].set_yticks(range(len(corr.columns)))
axes[0,1].set_xticklabels(corr.columns, rotation=45)
axes[0,1].set_yticklabels(corr.columns)
fig.colorbar(im, ax=axes[0,1])

# 🔹 3 Bar Graph
df.groupby('Age_Category')['Monthly_Rate'].mean().plot(kind='bar', ax=axes[0,2])
axes[0,2].set_title("Bar Graph", color='black')

# 🔹 4 Pie Chart
df.groupby('Sex')['Monthly_Rate'].mean().plot(kind='pie', autopct='%1.1f%%', ax=axes[1,0], radius=1.6)
axes[1,0].set_title("Pie Chart")
axes[1,0].set_ylabel("")

# 🔹 5 Donut Chart
race_data = df.groupby('Race')['Monthly_Rate'].mean()
axes[1,1].pie(race_data, autopct='%1.1f%%', radius=1.6)
centre_circle = plt.Circle((0,0),0.70,fc='white')
axes[1,1].add_artist(centre_circle)
axes[1,1].set_title("Donut Chart")

# 🔹 6 Box Plot
df.boxplot(column='Monthly_Rate', by='Age_Category', ax=axes[1,2])
axes[1,2].set_title("Box Plot")
axes[1,2].tick_params(axis='x', rotation=45)

# Remove extra title
plt.suptitle("")

# Adjust layout
plt.tight_layout()

plt.show()
