import pandas as pd
import matplotlib.pyplot as plt

df = pd.read_csv("cleaned_data.csv")

# Convert some columns to numeric for better correlation
df['Age_Code'] = df['Age_Category'].astype('category').cat.codes
df['Sex_Code'] = df['Sex'].astype('category').cat.codes
df['Race_Code'] = df['Race'].astype('category').cat.codes

# Select useful numeric columns
numeric_df = df[['Monthly_Rate', 'Age_Code', 'Sex_Code', 'Race_Code']]

# Correlation matrix
corr = numeric_df.corr()

plt.figure(figsize=(8,6))   # 🔥 important (increase size)

# Heatmap
plt.imshow(corr)

# Add labels
plt.xticks(range(len(corr.columns)), corr.columns, rotation=45)
plt.yticks(range(len(corr.columns)), corr.columns)

# Add color bar
plt.colorbar()

# 🔥 ADD GRID (this fixes your problem)
plt.grid(True)

plt.title("Improved Heatmap")

plt.show()