import pandas as pd

# Load dataset
df = pd.read_csv("C:/Users/Lenovo/Downloads/Monthly_Rates_of_Laboratory-Confirmed_COVID-19_Hospitalizations_from_the_COVID-NET_Surveillance_System.csv")

# Rename columns (easy to use)
df.columns = df.columns.str.strip().str.replace(" ", "_")

# Handle missing values
df = df.dropna()

# Convert Year_Month into datetime
df['Year_Month'] = pd.to_datetime(df['Year_Month'], format='%Y%m')

# Convert Monthly_Rate to numeric
df['Monthly_Rate'] = pd.to_numeric(df['Monthly_Rate'], errors='coerce')

# Remove duplicates
df = df.drop_duplicates()

# Save cleaned dataset
df.to_csv("cleaned_data.csv", index=False)

print("Data cleaned successfully!") 