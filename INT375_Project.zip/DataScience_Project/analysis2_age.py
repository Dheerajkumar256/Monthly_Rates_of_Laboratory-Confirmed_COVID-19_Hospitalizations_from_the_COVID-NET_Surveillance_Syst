import pandas as pd
import matplotlib.pyplot as plt

df = pd.read_csv("cleaned_data.csv")

age_data = df.groupby('Age_Category')['Monthly_Rate'].mean()

plt.figure()
age_data.plot(kind='bar', color='green')
plt.title("Hospitalization by Age Category")

plt.xticks(rotation=90)
plt.show()
